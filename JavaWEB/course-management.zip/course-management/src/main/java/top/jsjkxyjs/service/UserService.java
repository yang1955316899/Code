package top.jsjkxyjs.service;

import top.jsjkxyjs.entity.User;

public interface UserService {
	int doAddUser(User user);

}
