package top.jsjkxyjs.entity;

public class Class {
	private int id;
	private int Counselor;

	private String ClassName;

	private int College;

	private int Faculty;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCounselor() {
		return Counselor;
	}

	public void setCounselor(int counselor) {
		Counselor = counselor;
	}

	public String getClassName() {
		return ClassName;
	}

	public void setClassName(String className) {
		ClassName = className;
	}

	public int getCollege() {
		return College;
	}

	public void setCollege(int college) {
		College = college;
	}

	public int getFaculty() {
		return Faculty;
	}

	public void setFaculty(int faculty) {
		Faculty = faculty;
	}
}
