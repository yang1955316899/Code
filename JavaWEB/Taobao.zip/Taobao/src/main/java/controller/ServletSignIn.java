package controller;

import entity.User;
import service.Impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ServletSignIn extends HttpServlet {

	protected boolean SignIn(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		req.setCharacterEncoding("UTF-8");
		User user = new User();
		if (req.getSession().getAttribute("user") != null && ((User)req.getSession().getAttribute("user")).getUsername()!=null) {
			user = (User) req.getSession().getAttribute("user");
		} else if (req.getParameter("UserName") != null) {
			user.setUsername(Long.parseLong(req.getParameter("UserName")));
			user.setPassword(req.getParameter("UserPassword"));
		} else {
			return false;
		}
		user = new UserServiceImpl().doLogin(user);
		if (user.getUsername() != null) {
			req.getSession().removeAttribute("user");
			req.getSession().setAttribute("user", user);
			Cookie UserName = new Cookie("UserName", "" + user.getUsername());//创建一个键值对的cookie对象
			UserName.setMaxAge(60 * 60 * 24 * 7);//设置cookie的生命周期
			resp.addCookie(UserName);//添加到response中
			Cookie UserPassword = new Cookie("UserPassword", "" + user.getPassword());//创建一个键值对的cookie对象
			UserPassword.setMaxAge(60 * 60 * 24 * 7);//设置cookie的生命周期
			resp.addCookie(UserPassword);//添加到response中
			if (user.getAdmin() == 1)
				resp.sendRedirect("Admin.jsp");
			else
				resp.sendRedirect("index.jsp");
			return true;
		} else {
			return false;
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if (!SignIn(req, resp)){
			req.getSession().setAttribute("autologin","3");
			resp.sendRedirect("Sign-In.jsp");
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		if (!SignIn(req, resp)){
			req.getSession().setAttribute("autologin","3");
			resp.sendRedirect("index.jsp");
		}
	}
}