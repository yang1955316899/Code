package controller;

import entity.User;
import service.Impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


public class ServletChangeInfo extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		User user = new User(Integer.parseInt(req.getParameter("id")), Long.parseLong(req.getParameter("username")),req.getParameter("password"), Integer.parseInt(req.getParameter("admin")), req.getParameter("petname"));
		req.getSession().setAttribute("user", user);
		new UserServiceImpl().changeInfo(user);
		resp.sendRedirect("Home.jsp");
	}
}
