package controller;

import entity.User;
import service.Impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ServletSignUp extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = new User();
		user.setUsername(Long.parseLong(req.getParameter("Username")));
		user.setPassword(req.getParameter("UserPassword"));
		if (!new UserServiceImpl().SignUp(user)) {
			resp.sendRedirect("Sign-Up.jsp");
		} else {
			user = new UserServiceImpl().doLogin(user);
			req.removeAttribute("user");
			req.getSession().setAttribute("user", user);
			resp.sendRedirect("index.jsp");
		}
	}
}
