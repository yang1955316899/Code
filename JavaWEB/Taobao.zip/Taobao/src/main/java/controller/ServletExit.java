package controller;

import entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ServletExit extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getSession().removeAttribute("user");
		Cookie[] cookies = req.getCookies();
		if (cookies != null && cookies.length >= 0) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("UserName")) {
					Cookie UserName = new Cookie("UserName", "0");
					resp.addCookie(UserName);
				}
				if (cookie.getName().equals("UserPassword")) {
					Cookie UserPassword = new Cookie("UserName", "0");
					resp.addCookie(UserPassword);
				}
			}
		}
		resp.sendRedirect("index.jsp");
	}
}
