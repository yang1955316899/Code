package entity;

public class User {
	private int id;
	private Long username;
	private String password;
	private int admin;
	private String petname;

	public User() {
	}

	public User(int id, Long username, String password, int admin, String petname) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.admin = admin;
		this.petname = petname;
	}

	public String getPetname() {
		return petname;
	}

	public void setPetname(String petname) {
		this.petname = petname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getUsername() {
		return username;
	}

	public void setUsername(Long username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAdmin() {
		return admin;
	}

	public void setAdmin(int admin) {
		this.admin = admin;
	}
}
