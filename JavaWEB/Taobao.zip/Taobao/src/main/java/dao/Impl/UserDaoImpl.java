package dao.Impl;

import dao.UserDao;
import entity.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	@Override
	public Connection getConnection() {
		/*连接数据库对象*/
		Connection conn = null;
		/*返回数据库连接的方法*/
		try {
			String url = "jdbc:mysql://localhost:3306/taobao";
			/*注册驱动*/
			Class.forName("com.mysql.cj.jdbc.Driver");
			/*获取连接*/
			conn = DriverManager.getConnection(url, "root", "root");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public int excuteSQL(String sql, String[] arr) {
		int cou = 0;
		conn = getConnection();
		try {
			ps = conn.prepareStatement(sql);
			if (arr != null && arr.length > 0) {
				for (int tem = 0; tem < arr.length; tem++) {
					ps.setString(tem + 1, arr[tem]);
				}
			}
			cou = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeAll(rs, ps, conn);
		}
		return cou;
	}

	@Override
	public List getAllUsers() {
		List<User> users = new ArrayList<>();
		conn = getConnection();
		String sql = "select * from user";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) { // 指针
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getLong("Username"));
				user.setPassword(rs.getString("UserPassword"));
				user.setAdmin(rs.getInt("Admin"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();//对数据库中的值进行更新
		} finally {
			closeAll(rs, ps, conn);
		}
		return users;
	}

	@Override
	public User getUserByUserName(String SQL, String[] arr) {
		conn = getConnection();
		User user = new User();
		try {
			ps = conn.prepareStatement(SQL);
			//占位符替换
			if (arr != null && arr.length > 0)
				for (int tem = 0; tem < arr.length; tem++)
					ps.setString(tem + 1, arr[tem]);

			rs = ps.executeQuery();//对数据库中的值进行更新
			if (rs.next()) { // 指针
				user.setUsername(rs.getLong("UserName"));
				user.setPassword(rs.getString("UserPassword"));
				user.setId(rs.getInt("id"));
				user.setAdmin(rs.getInt("Admin"));
				user.setPetname(rs.getString("Petname"));
			} else {
				user.setUsername(null);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeAll(rs, ps, conn);
		}
		return user;
	}

	@Override
	public void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) {
		if (rs != null) {
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (ps != null) {
			try {
				ps.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
