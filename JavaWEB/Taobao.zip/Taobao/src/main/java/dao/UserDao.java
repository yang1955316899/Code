package dao;

import entity.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public interface UserDao {
	//连接数据库
	Connection getConnection();
	//增删改sql语句+可变参数形成
	int excuteSQL(String sql, String[] arr);
	//返回所有用户
	List getAllUsers();
	//通过id查找返回对应的id
	User getUserByUserName(String SQL,String[] arr);
	//关闭所有对数据库的连接
	void closeAll(ResultSet rs, PreparedStatement ps, Connection conn);
}
