package service;

import entity.User;

import java.util.List;

public interface UserService {
	//注册,返回布尔值
	boolean SignUp(User user);
	//登陆,返回状态信息
	User doLogin(User user);
	//返回用户信息
	List getAllUsers();

	boolean changeInfo(User user);
}
