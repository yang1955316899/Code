package service.Impl;

import dao.Impl.UserDaoImpl;
import entity.User;
import service.UserService;

import java.util.List;

public class UserServiceImpl implements UserService {
	UserDaoImpl userDao = new UserDaoImpl();

	@Override
	public boolean SignUp(User user) {
		String SQL = "insert into user (UserName,UserPassword) values (?,?)";
		String[] arr = {"" + user.getUsername(), "" + user.getPassword()};
		return userDao.excuteSQL(SQL, arr) > 0;
	}

	@Override
	public User doLogin(User user) {
		String SQL = "select * from user where UserName = ? and UserPassword= ?";
		String[] arr = {"" + user.getUsername(), user.getPassword()};
		return userDao.getUserByUserName(SQL, arr);
	}

	@Override
	public List getAllUsers() {
		return userDao.getAllUsers();
	}

	@Override
	public boolean changeInfo(User user) {
		String SQL = "UPDATE USER SET UserName = ?,UserPassword = ?,Petname = ? WHERE id = " + user.getId();
		String[] arr = {"" + user.getUsername(), user.getPassword(), user.getPetname()};
		return userDao.excuteSQL(SQL, arr) > 0;
	}
}
