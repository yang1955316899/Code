let phone_input = document.querySelector('.phone');
let password_input = document.querySelector('.password');
let btn = document.querySelector('.submit');
let error = document.querySelector('.error');

btn.addEventListener('click', function () {
    if (phone_input.value.length >= 0 && phone_input.value.length < 11) {
        error.style.visibility = 'visible';
        error.innerHTML = '请输入正确的手机号';
    } else if (password_input.value.length == 0) {

        error.style.visibility = 'visible';
        error.innerHTML = '请输入密码';
    }
    else
        document.querySelector('#form').submit();

})


