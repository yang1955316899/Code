window.addEventListener('DOMContentLoaded', function () {
    //下拉菜单栏

    function display(elemt) {
        elemt.addEventListener('mouseover', function () {
            elemt.querySelector('ul').style.display = 'block';
        })
        elemt.addEventListener('mouseleave', function () {
            elemt.querySelector('ul').style.display = 'none';
        })
    }

    let global = document.querySelector('.global');
    display(global);
    let mytaobao = document.querySelector('.mytaobao');
    display(mytaobao);
    let star = document.querySelector('.star');
    display(star);
})