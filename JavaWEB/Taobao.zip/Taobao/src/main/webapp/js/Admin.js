window.addEventListener('DOMContentLoaded', function () {
    let exit = document.querySelector('.exit');
    if (document.querySelector('.username').innerHTML.indexOf("点击登陆") == -1) {
        document.querySelector('.free-Sign-Up').style.display = 'none';
        exit.style.display = "inline-block";
        document.querySelector('.username').href = "Admin.jsp";
    }
    //对输入的数字进行校验
    document.querySelector('.form-control').addEventListener("keyup", function () {
            this.value = this.value.replace(/\D/g, '')

        }
    )
})

